/*
 * @Author: fish 973841082@qq.com
 * @Date: 2022-12-22 21:52:57
 * @LastEditors: fish 973841082@qq.com
 * @LastEditTime: 2022-12-23 15:38:37
 * @FilePath: /VINS-Mono/feature_tracker/include/linefeature_tracker.h
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */

#pragma once

#include <iostream>
#include <queue>

#include "camodocal/camera_models/CameraFactory.h"
#include "camodocal/camera_models/CataCamera.h"
#include "camodocal/camera_models/PinholeCamera.h"
#include "camodocal/camera_models/EquidistantCamera.h"
#include <camodocal/camera_models/Camera.h>

#include <opencv2/features2d.hpp>
#include <opencv2/opencv.hpp>
#include "parameters.h"
#include "tic_toc.h"
#include "../src/line_match/src/line.h"
#include <opencv2/features2d.hpp>



#include "../src/line_match/src/line.h"
#include "../src/line_match/src/edline_detector.h"
#include "../src/line_match/src/line_matching.h"


extern std::string config_file_yaml;

using namespace std;

class FrameLines
{
public:
    int frame_id;
    cv::Mat img;
    
    vector<Line> vecLine;
    vector< int > lineID;
};
typedef shared_ptr< FrameLines > FrameLinesPtr;


class LineFeatureTracker
{
  public:
    LineFeatureTracker();

    vector<Line> undistortedLineEndPoints();

    void readImage(const cv::Mat &_img);
    void readIntrinsicParameter(const string &calib_file);

    FrameLinesPtr prev_frame, cur_frame;

    cv::Mat undist_map1_, undist_map2_ , K_;

    camodocal::CameraPtr m_camera;       // pinhole camera

    private:
    EDLineParam line_param ;
    EDLineDetector line_detctor;
    LineMatching line_matching ;  
    vector<Line> key_lines;

    int all_lines_cnt = -1;
    uchar prev_idx_debug = 0;
    uchar cur_idx_debug = 1;
    double segAngle(const Line &s);

    
    // int frame_cnt;
    // vector<int> ids;                     // 每个特征点的id
    // vector<int> linetrack_cnt;           // 记录某个特征已经跟踪多少帧了，即被多少帧看到了

};
