/*
 * @Description: 
 * @Version: 
 * @Author: 
 * @Date: 2022-11-24 09:39:49
 * @LastEditors: fish 973841082@qq.com
 * @LastEditTime: 2022-12-22 19:12:44
 */
#pragma once
#include <string>
#include <algorithm>
#include <iostream>

#include <eigen3/Eigen/Dense>

#include <opencv2/opencv.hpp>
#include <opencv2/line_descriptor.hpp>
#include <opencv2/line_descriptor/descriptor.hpp>

#include <camodocal/camera_models/Camera.h>
#include <camodocal/camera_models/CameraFactory.h>

#include "../src/line_match/src/line.h"
#include "../src/line_match/src/edline_detector.h"
#include "../src/line_match/src/line_matching.h"


// Hypotheses
struct Line_info
{
    Eigen::Vector3d para;
    double length;
	double orientation;
};
struct Param
{
    float fx;
    float cx;
    float cy;
    float fy;
};
extern cv::Mat img_vp_pub;

class vanishing_point_detection
{
private:

    void get_vp_hyp_Lines(std::vector<Line> &_cur_keylines,std::vector<Line_info> &_line_infos, 
        std::vector<std::vector<Eigen::Vector3d> > &_vp_hypotheses);
    /* data */
    void get_sphere_grids(std::vector<Line> &_cur_keyLine,std::vector<Line_info> &_line_infos,
        std::vector<std::vector<double> > &_sphere_grid );
    void get_best_vps_hyp( std::vector<std::vector<double> > &sphere_grid, std::vector<std::vector<Eigen::Vector3d> >  &vp_hypo, std::vector<Eigen::Vector3d> &vps  );
    void lines2Vps(std::vector<Line> &_cur_keylines,std::vector<Eigen::Vector3d> &_vps, std::vector<std::vector<int> > &_clusters,std::vector<int> &_vp_idx);
    void draw_clusters( cv::Mat &_img, std::vector<Line> &_lines, std::vector<std::vector<int> > &_clusters,std::vector<int> &_vp_idx,std::vector<Eigen::Vector3d> &_vps);
    
    
    camodocal::CameraPtr m_camera; ///< geometric camera model
    
	// cv::Point2d pp;
	// double f;
	// double noiseRatio;
public:
    Param param;
    
    double th_angle = 1.0 / 180.0 * CV_PI;
    double noise_ratio = 0.5;
    double conf_efficience = 0.9999;
    vanishing_point_detection() = default;
    vanishing_point_detection(float _fx,float _cx,float _fy,float _cy);
    void run_vanishing_point_detection(cv::Mat _img,std::vector<Line> &_cur_keylines,std::vector<Eigen::Vector3d> &_vps,std::vector<int> &_vps_idx);
    ~vanishing_point_detection() = default;
    void get_line_info(std::vector<Line> &_cur_keylines,std::vector<Line_info> &_line_infos);
};


