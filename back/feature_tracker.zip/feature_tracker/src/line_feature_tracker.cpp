#include "../include/line_feature_tracker.h"
#include <glog/logging.h>

using namespace std;

// [-pi/2:pi/2]
double LineFeatureTracker::segAngle(const Line &s) {
  if (s.line_endpoint[2] > s.line_endpoint[0])
    return std::atan2(s.line_endpoint[3] - s.line_endpoint[1], s.line_endpoint[2] - s.line_endpoint[0]);
  else
    return std::atan2(s.line_endpoint[1]- s.line_endpoint[3] , s.line_endpoint[0] - s.line_endpoint[2]);
}
void LineFeatureTracker::readIntrinsicParameter(const string &calib_file)
{
    // ROS_INFO("reading paramerter of camera %s", calib_file.c_str());

    m_camera = camodocal::CameraFactory::instance()->generateCameraFromYamlFile(calib_file);
    K_ = m_camera->initUndistortRectifyMap(undist_map1_,undist_map2_);    

}
LineFeatureTracker::LineFeatureTracker()
{   
    // // m_camera->initUndistortRectifyMap
    // m_camera = camodocal::CameraFactory::instance()->generateCameraFromYamlFile(calib_file);
    // K_ = m_camera->initUndistortRectifyMap(undist_map1_,undist_map2_);  


    EDLineParam param = {5, 1,30, 10, 2, 10, 1.8};
    line_detctor = EDLineDetector(param);
    line_matching = LineMatching();

    all_lines_cnt = 0;
}


vector<Line> LineFeatureTracker::undistortedLineEndPoints()
{
    vector<Line> un_lines;
    un_lines.clear();
    un_lines = cur_frame->vecLine;
    float fx = K_.at<float>(0, 0);
    float fy = K_.at<float>(1, 1);
    float cx = K_.at<float>(0, 2);
    float cy = K_.at<float>(1, 2);

    for (unsigned int i = 0; i <cur_frame->vecLine.size(); i++)
    {
        un_lines[i].line_endpoint[0] = (cur_frame->vecLine[i].line_endpoint[0] - cx)/fx;
        un_lines[i].line_endpoint[1] = (cur_frame->vecLine[i].line_endpoint[1] - cy)/fy;
        un_lines[i].line_endpoint[2] = (cur_frame->vecLine[i].line_endpoint[2] - cx)/fx;
        un_lines[i].line_endpoint[3] = (cur_frame->vecLine[i].line_endpoint[3] - cy)/fy;
    }
    return un_lines;
}



void LineFeatureTracker::readImage(const cv::Mat &_img)
{
    cv::Mat img;
    cv::remap(_img, img, undist_map1_, undist_map2_, CV_INTER_LINEAR);


    if (EQUALIZE)   // 直方图均衡化
    {
        cv::Ptr<cv::CLAHE> clahe = cv::createCLAHE(3.0, cv::Size(8, 8));
        clahe->apply(img, img);
    }

    bool first_img = false;
    // 构造新的一个帧
    if(cur_frame == nullptr){
        cur_frame.reset(new FrameLines);
        prev_frame.reset(new FrameLines);

        cur_frame->img = img;
        prev_frame->img = img;

        first_img = true;
        cout<<"x first"<<std::endl;
     
    }
    else{
        cur_frame.reset(new FrameLines);
        cur_frame->img = img;
    }
    // 线段检测
    line_detctor.EDline(cur_frame->img , cur_frame->vecLine, false);


    if(cur_frame->vecLine.empty()) {
  
        line_detctor.EDline(prev_frame->img, cur_frame->vecLine, false);

        if(cur_frame->vecLine.empty()){
        
            prev_frame->img = cur_frame->img;
            prev_frame->vecLine.clear();
            prev_frame->lineID.clear();
            

        }
    }

    for(size_t i=0; i<cur_frame->vecLine.size(); ++i){

        if(first_img){
            cur_frame->lineID.push_back(all_lines_cnt++);
        }
        else{
            cur_frame->lineID.push_back(-1);     
        }
    }

    // 第二帧开始
    if(prev_frame->vecLine.size() > 0)
    {
        // 匹配的索引
        std::vector<int> line_prev_to_line_cur;

        line_matching.Matching(prev_frame->img,
                                    cur_frame->img,
                                    prev_frame->vecLine,
                                    cur_frame->vecLine,
                                    line_prev_to_line_cur,
                                    *(cv::Mat*)NULL,
                                    *(cv::Mat*)NULL,
                                    *(cv::Mat*)NULL,
                                    true,//自适应
                                    true,//<滤波
                                    0,//<debug
                                    prev_idx_debug++, cur_idx_debug++);
        // cv::waitKey(10);
        for(size_t i = 0; i<prev_frame->vecLine.size(); ++i)
        {
            int prev_to_cur_id = line_prev_to_line_cur[i];
            
            if(prev_to_cur_id == -1)
                continue;
            cur_frame->lineID[prev_to_cur_id] = prev_frame->lineID[i];
        }
        vector<Line> vecLine_tracked, vecLine_new;
        vector< int > lineID_tracked, lineID_new;


        // 将跟踪的线和没跟踪上的线进行区分
        for (size_t i = 0; i < cur_frame->vecLine.size(); ++i)
        {
            if( cur_frame->lineID[i] == -1)
            {
                cur_frame->lineID[i] = all_lines_cnt++;
                vecLine_new.push_back(cur_frame->vecLine[i]);
                lineID_new.push_back(cur_frame->lineID[i]);
            }
            
            else
            {
                vecLine_tracked.push_back(cur_frame->vecLine[i]);
                lineID_tracked.push_back(cur_frame->lineID[i]);
            }
        }     

        vector<Line> h_Line_new, v_Line_new;
        vector< int > h_lineID_new,v_lineID_new;
        for (size_t i = 0; i < vecLine_new.size(); ++i)
        {
            double angle = segAngle(vecLine_new[i]);
            if((((angle >= 3.14/4 && angle <= 3*3.14/4))||(angle <= -3.14/4 && angle >= -3*3.14/4)))
            {
                h_Line_new.push_back(vecLine_new[i]);
                h_lineID_new.push_back(lineID_new[i]);
            }
            else
            {
                v_Line_new.push_back(vecLine_new[i]);
                v_lineID_new.push_back(lineID_new[i]);
            }      
        }  

        int h_line,v_line;
        h_line = v_line =0;
        for (size_t i = 0; i < vecLine_tracked.size(); ++i)
        {
            double angle = segAngle(vecLine_new[i]);
            if((((angle >= 3.14/4 && angle <= 3*3.14/4))||(angle <= -3.14/4 && angle >= -3*3.14/4)))
            {
                h_line ++;
            }
            else
            {
                v_line ++;
            }
        } 

        int diff_h = 30 - h_line;
        int diff_v = 30 - v_line;

        if( diff_h > 0)    // 补充线条
        {
            int kkk = 1;
            if(diff_h > h_Line_new.size())
                diff_h = h_Line_new.size();
            else 
                kkk = int(h_Line_new.size()/diff_h);
            for (int k = 0; k < diff_h; ++k) 
            {
                vecLine_tracked.push_back(h_Line_new[k]);
                lineID_tracked.push_back(h_lineID_new[k]);
            }
            // std::cout  <<"h_kkk = " <<kkk<<" diff_h = "<<diff_h<<" h_Line_new.size() = "<<h_Line_new.size()<<std::endl;
        }   
        if( diff_v > 0)    // 补充线条
        {
            int kkk = 1;
            if(diff_v > v_Line_new.size())
                diff_v = v_Line_new.size();
            else 
                kkk = int(v_Line_new.size()/diff_v);
            for (int k = 0; k < diff_v; ++k)  
            {
                vecLine_tracked.push_back(v_Line_new[k]);
                lineID_tracked.push_back(v_lineID_new[k]);
            }            // std::cout  <<"v_kkk = " <<kkk<<" diff_v = "<<diff_v<<" v_Line_new.size() = "<<v_Line_new.size()<<std::endl;
        }

        cur_frame->vecLine = vecLine_tracked;
        cur_frame->lineID = lineID_tracked;

    }

    prev_frame = cur_frame;
    
}






