/*
 * @Author: fish 973841082@qq.com
 * @Date: 2022-12-22 21:52:44
 * @LastEditors: fish 973841082@qq.com
 * @LastEditTime: 2022-12-23 16:43:14
 * @FilePath: /VINS-Mono/feature_tracker/src/line_feature_tracker_node.cpp
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
#include <ros/ros.h>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/image_encodings.h>
#include <sensor_msgs/PointCloud.h>
#include <sensor_msgs/Imu.h>
#include <cv_bridge/cv_bridge.h>
#include <message_filters/subscriber.h>

#include "../include/line_feature_tracker.h"


int pub_count = 1;
std::string config_file_yaml;
ros::Publisher pub_img,pub_match;

LineFeatureTracker line_feature_tracker;

// static std::unique_ptr<LineFeatureTracker> line_feature_tracker(new LineFeatureTracker());

void img_callback(const sensor_msgs::ImageConstPtr &img_msg)
{
    
    cv::Mat img;

    try {
        img = cv_bridge::toCvShare(img_msg, "bgr8")->image;
    } catch (cv_bridge::Exception& e) {
        return;
    }   

    static double first_image_time = img_msg->header.stamp.toSec();
    // frequency control, 如果图像频率低于一个值
    if (round(1.0 * pub_count / (img_msg->header.stamp.toSec() - first_image_time)) <= FREQ)
    {
        PUB_THIS_FRAME = true;
        // reset the frequency control
        if (abs(1.0 * pub_count / (img_msg->header.stamp.toSec() - first_image_time) - FREQ) < 0.01 * FREQ)
        {
            first_image_time = img_msg->header.stamp.toSec();
            pub_count = 0;
        }
    }
    else
        PUB_THIS_FRAME = false;  

    if(PUB_THIS_FRAME){

        cv::Mat gray;
        cv::cvtColor(img, gray, cv::COLOR_RGB2GRAY);

        pub_count++;

        sensor_msgs::PointCloudPtr feature_lines(new sensor_msgs::PointCloud);
        sensor_msgs::ChannelFloat32 id_of_line;   //  feature id
        sensor_msgs::ChannelFloat32 u_of_endpoint;    //  u
        sensor_msgs::ChannelFloat32 v_of_endpoint;    //  v

        feature_lines->header = img_msg->header;
        feature_lines->header.frame_id = "world";

        line_feature_tracker.readImage(gray);

        auto un_lines = line_feature_tracker.undistortedLineEndPoints();
        // read
        auto &ids = line_feature_tracker.cur_frame->lineID;
        for (unsigned int j = 0; j < ids.size(); j++)
        {

            int p_id = ids[j];

            geometry_msgs::Point32 p;
            p.x = un_lines[j].line_endpoint[0];
            p.y = un_lines[j].line_endpoint[1];
            p.z = 1;

            feature_lines->points.push_back(p);
            
            id_of_line.values.push_back(p_id);

            u_of_endpoint.values.push_back(un_lines[j].line_endpoint[2]);
            v_of_endpoint.values.push_back(un_lines[j].line_endpoint[3]);
        }        
        feature_lines->channels.push_back(id_of_line);
        feature_lines->channels.push_back(u_of_endpoint);
        feature_lines->channels.push_back(v_of_endpoint);
        // ROS_DEBUG("publish %f, at %f", feature_lines->header.stamp.toSec(), ros::Time::now().toSec());
        pub_img.publish(feature_lines);
    }

    

}


int main(int argc, char **argv)
{
    ros::init(argc, argv, "line_feature_tracker");
    ros::NodeHandle n("~");
    ros::console::set_logger_level(ROSCONSOLE_DEFAULT_NAME, ros::console::levels::Info);
    config_file_yaml = readParameters(n);
    line_feature_tracker.readIntrinsicParameter(config_file_yaml);
    // ROS_INFO("start line feature");
    ros::Subscriber sub_img = n.subscribe(IMAGE_TOPIC, 100, img_callback);


    // 发布点云
    pub_img = n.advertise<sensor_msgs::PointCloud>("line_feature", 1000);
    // 发布图像
    pub_match = n.advertise<sensor_msgs::Image>("line_feature_img",1000);

    ros::spin();
    return 0;
}
