/*
 * @Description: 
 * @Version: 
 * @Author: 
 * @Date: 2022-11-20 22:35:54
 * @LastEditors: fish
 * @LastEditTime: 2022-11-20 23:26:21
 */
#ifndef LINE_H
#define LINE_H

#include <array>
#include <vector>
#include <opencv2/opencv.hpp>

struct Line {
    std::array<float, 4> line_endpoint;
    std::array<double, 3> line_equation;
    std::array<float, 2> center;
    float length;

    std::vector<cv::Point2f> kps;
    std::vector<cv::Point2f> kps_init;
    std::vector<cv::Vec2f> dirs;
};

#endif