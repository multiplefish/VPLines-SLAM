/*
 * @Description: 
 * @Version: 
 * @Author: 
 * @Date: 2022-11-24 09:39:33
 * @LastEditors: fish 973841082@qq.com
 * @LastEditTime: 2022-12-22 19:13:47
 */
/**
 * @description: 先由getVPHypVia2Lines穷举所有的灭点，
 * 	在get_sphere_grids来构建极坐标系搜索网络便于验证灭点，
 * 	在get_best_vps_hyp进行所有的假设进行验证，获取响应的ps
 * 	在lines2Vps根据阈值1.0 / 180.0 * CV_PI进行分类，对线特征进行分类
 * @return {*}
 * @author: fish
 */
#include "../include/vanishing_point_detection.h"
#include "../include/tic_toc.h"
#include <glog/logging.h>
#include <thread>
cv::Mat img_vp_pub;
vanishing_point_detection::vanishing_point_detection(float _fx,float _cx,float _fy,float _cy)
{
	param = {_fx,_cx,_fy,_cy};
}
void vanishing_point_detection::get_line_info(std::vector<Line> &_cur_keylines,std::vector<Line_info> &_line_infos){
	// get the parameters of each line
	// 获取所有线对的信息
	int num = _cur_keylines.size();
	_line_infos.resize( num );
	for ( int i=0; i<num; ++i )
	{
		Eigen::Vector3d p1 = Eigen::Vector3d(_cur_keylines[i].line_endpoint[0], _cur_keylines[i].line_endpoint[1], 1.0 );
        Eigen::Vector3d p2 = Eigen::Vector3d(_cur_keylines[i].line_endpoint[2], _cur_keylines[i].line_endpoint[3],1.0);

		// 叉乘信息表示像素面两点的直线系数
		_line_infos[i].para = p1.cross( p2 );
		// 长度
		double dx = _cur_keylines[i].line_endpoint[0] - _cur_keylines[i].line_endpoint[2];
		double dy = _cur_keylines[i].line_endpoint[1] - _cur_keylines[i].line_endpoint[3];
		_line_infos[i].length = sqrt( dx * dx + dy * dy );
		// 角度
		_line_infos[i].orientation = atan2( dy, dx );
		if ( _line_infos[i].orientation < 0 )
		{
			_line_infos[i].orientation += CV_PI;
		}
	}
}
void vanishing_point_detection::run_vanishing_point_detection(cv::Mat _img,std::vector<Line> &_cur_keylines,std::vector<Eigen::Vector3d> &_vps,std::vector<int> &_vps_idx){
	std::vector<Line_info> line_infos;
	std::vector<std::vector<Eigen::Vector3d> > vp_hypotheses;
	std::vector<std::vector<double> > sphere_grid;
	std::vector<std::vector<int>> clusters;



	get_line_info(_cur_keylines,line_infos);
	std::thread get_vpshyp_thread([&](){
		get_vp_hyp_Lines(_cur_keylines,line_infos,vp_hypotheses);
	});
	std::thread get_sphere_grids_thread([&](){
		get_sphere_grids(_cur_keylines,line_infos,sphere_grid);
	});
	get_vpshyp_thread.join();
	get_sphere_grids_thread.join();
	// LOG(INFO)<<"entire lines feature tracker processing costs:"<< t_process.toc()<<"ms"<<std::endl;

	get_best_vps_hyp(sphere_grid,vp_hypotheses,_vps);
	lines2Vps(_cur_keylines,_vps,clusters,_vps_idx);

	draw_clusters(_img,_cur_keylines,clusters,_vps_idx,_vps);


}
/**
 * @description: *
 * @param {vector<Line>} &_cur_keylines 提取的线
 * @param {vector<Line_info>} &_line_infos 两条线的信息
 * @param {vector<std::vector<Eigen::Vector3d> >} &_vp_hypotheses 灭点假设
 * @return {*}
 * @author: fish
 */
void vanishing_point_detection::get_vp_hyp_Lines(std::vector<Line> &_cur_keylines,std::vector<Line_info> &_line_infos, std::vector<std::vector<Eigen::Vector3d> > &_vp_hypotheses){

    int num = _cur_keylines.size();
	// 聚类的迭代次数计算，类似Ransac的算法计算
	double p = 1.0 / 3.0 * pow( 1.0 - noise_ratio, 2 );

	int it = log( 1 - conf_efficience ) / log( 1.0 - p );
	
	int numVp2 = 360;
	double stepVp2 = 2.0 * CV_PI / numVp2;

	// // get the parameters of each line
	// // 获取所有线对的信息
	
	// _line_infos.resize( num );
	// for ( int i=0; i<num; ++i )
	// {
	// 	Eigen::Vector3d p1 = Eigen::Vector3d(_cur_keylines[i].line_endpoint[0], _cur_keylines[i].line_endpoint[1], 1.0 );
    //     Eigen::Vector3d p2 = Eigen::Vector3d(_cur_keylines[i].line_endpoint[2], _cur_keylines[i].line_endpoint[3],1.0);

	// 	// 叉乘信息表示像素面两点的直线系数
	// 	_line_infos[i].para = p1.cross( p2 );
	// 	// 长度
	// 	double dx = _cur_keylines[i].line_endpoint[0] - _cur_keylines[i].line_endpoint[2];
	// 	double dy = _cur_keylines[i].line_endpoint[1] - _cur_keylines[i].line_endpoint[3];
	// 	_line_infos[i].length = sqrt( dx * dx + dy * dy );
	// 	// 角度
	// 	_line_infos[i].orientation = atan2( dy, dx );
	// 	if ( _line_infos[i].orientation < 0 )
	// 	{
	// 		_line_infos[i].orientation += CV_PI;
	// 	}
	// }
	// 迭代计算灭点假设
	// get vp hypothesis for each iteration
	_vp_hypotheses = std::vector<std::vector<Eigen::Vector3d> > ( it * numVp2, std::vector<Eigen::Vector3d>(4) );
	int count = 0;
	srand((unsigned)time(NULL));  
	for ( int i = 0; i < it; ++ i )
	{
		int idx1 = rand() % num;
		int idx2 = rand() % num;
		while ( idx2 == idx1 )
		{
			idx2 = rand() % num;
		}

		// 假设挑选出的2条线段属于同一个消影点，叉乘计算出第一个消影点的像素坐标
		Eigen::Vector3d vp1_Img = _line_infos[idx1].para.cross( _line_infos[idx2].para );
		
		if ( vp1_Img(2) == 0 )
		{
			i --;
			continue;
		}
		// LOG(INFO)<<std::endl<<vp1_Img<<std::endl;
		// 把像素点转化在球体坐标系
		Eigen::Vector3d vp1(  vp1_Img(0) / vp1_Img(2) - param.cx, vp1_Img(1) / vp1_Img(2) - param.cy, param.fx);

		if ( vp1(2) == 0 )  vp1(2) = 0.0011; 
		//消影点向量单位化
		double N = sqrt( vp1(0) * vp1(0) + vp1(1) * vp1(1) + vp1(2) * vp1(2) );
		vp1 *= 1.0 / N;

		// get the vp2 and vp3
        Eigen::Vector3d vp2( 0.0, 0.0, 0.0 );
        Eigen::Vector3d vp3( 0.0, 0.0, 0.0 );
        Eigen::Vector3d vp4( 0.0, 0.0, 0.0 );
        
		for ( int j = 0; j < numVp2; ++ j )
		{
			// vp2
			double lambda = j * stepVp2;
			// 球经纬度坐标转化为空间坐标，原理和公式见详解
			double k1 = vp1(0) * sin( lambda ) + vp1(1) * cos( lambda );
			double k2 = vp1(2);

			// 求出的phi,根据lambda迭代计算vp2
			double phi = atan( - k2 / k1 );

			double Z = cos( phi );
			double X = sin( phi ) * sin( lambda );
			double Y = sin( phi ) * cos( lambda );

			vp2(0) = X;  vp2(1) = Y;  vp2(2) = Z;
			if ( vp2(2) == 0.0 ) { vp2(2) = 0.0011; }
			N = sqrt( vp2(0) * vp2(0) + vp2(1) * vp2(1) + vp2(2) * vp2(2) );
			vp2 *= 1.0 / N;
			//归一化第二个消影点,因为不可能在相机后方，所以当vp2(2)<0时取反方向。
			if ( vp2(2) < 0 ) { vp2 *= -1.0; }		

			// vp3	
			//第三个消影点直接叉乘获得
			vp3 = vp1.cross( vp2 );
			if ( vp3(2) == 0.0 ) { vp3(2) = 0.0011; }
			N = sqrt( vp3(0) * vp3(0) + vp3(1) * vp3(1) + vp3(2) * vp3(2) );
			vp3 *= 1.0 / N;
			//归一化第二个消影点,因为不可能在相机后方，所以当vp2(2)<0时取反方向。
			if ( vp3(2) < 0 ) { vp3 *= -1.0; }		

			////至此，生成了第一次迭代的一组消影点假设
			_vp_hypotheses[count][0] = Eigen::Vector3d( vp1(0), vp1(1), vp1(2) );
			_vp_hypotheses[count][1] = Eigen::Vector3d( vp2(0), vp2(1), vp2(2) );
			_vp_hypotheses[count][2] = Eigen::Vector3d( vp3(0), vp3(1), vp3(2) );

			count ++;
		}
	}    


    
}

/**
 * @description: *
 * _cur_keyLine ：线
 * _line_infos：信息
 * _sphere_grid ：极坐标球化
 * @return {*}
 * @author: fish
 */
void vanishing_point_detection::get_sphere_grids(std::vector<Line> &_cur_keyLine,std::vector<Line_info> &_line_infos,
								std::vector<std::vector<double> > &_sphere_grid ){

	// build sphere grid with 1 degree accuracy
	// 将构建用于快速查询以验证假设的极坐标网格
	double angelAccuracy = 1.0 / 180.0 * CV_PI;
	double angleSpanLA = CV_PI / 2.0;
	double angleSpanLO = CV_PI * 2.0;
	int gridLA = angleSpanLA / angelAccuracy;
	int gridLO = angleSpanLO / angelAccuracy;

	_sphere_grid = std::vector< std::vector<double> >( gridLA, std::vector<double>(gridLO) );
	for ( int i=0; i<gridLA; ++i )
	{
		for ( int j=0; j<gridLO; ++j )
		{
			_sphere_grid[i][j] = 0.0;
		}
	}

	// put intersection points into the grid
	double angelTolerance = 60.0 / 180.0 * CV_PI;
	Eigen::Vector3d ptIntersect;
	double x = 0.0, y = 0.0;
	double X = 0.0, Y = 0.0, Z = 0.0, N = 0.0;
	double latitude = 0.0, longitude = 0.0;
	int LA = 0, LO = 0;
	double angleDev = 0.0;
	for ( int i=0; i<_cur_keyLine.size()-1; ++i )
	{
		for ( int j=i+1; j<_cur_keyLine.size(); ++j )
		{	
			//计算两条线的交点
			ptIntersect = _line_infos[i].para.cross( _line_infos[j].para );

			if ( ptIntersect(2,0) == 0 )
			{
				continue;
			}
			// 归一化
			x = ptIntersect(0,0) / ptIntersect(2,0);
			y = ptIntersect(1,0) / ptIntersect(2,0);
			//转换为等效球坐标,求出latitude和longtitude
			X = x - param.cx;
			Y = y - param.cy;
			Z = param.fx;

			N = sqrt( X * X + Y * Y + Z * Z );

			latitude = acos( Z / N );
			longitude = atan2( X, Y ) + CV_PI;
			//找到对应的纬度网格
			LA = int( latitude / angelAccuracy );
			if ( LA >= gridLA ) 
			{
				LA = gridLA - 1;
			}
			//找到对应的经度网格
			LO = int( longitude / angelAccuracy );
			if ( LO >= gridLO ) 
			{
				LO = gridLO - 1;
			}

			// 计算线段的角度偏差，超出阈值则判断必定不属于同一个消影点
			angleDev = std::abs( _line_infos[i].orientation - _line_infos[j].orientation );
			angleDev = std::min( CV_PI - angleDev, angleDev );
			if ( angleDev > angelTolerance )
			{
				continue;
			}
			// 向对应极坐标网格内增加响应数值，长度越长，角度偏差适中的,权重越高
			_sphere_grid[LA][LO] += sqrt( _line_infos[i].length * _line_infos[j].length ) * ( std::sin( 2.0 * angleDev ) + 0.2 ); // 0.2 is much robuster
		}
	}

	// 最后又做了一个3x3的高斯平滑滤波器以去除噪声，达到更鲁棒精确的检测效果。
	int halfSize = 1;
	int winSize = halfSize * 2 + 1;
	int neighNum = winSize * winSize;

	// get the weighted line length of each grid
	std::vector< std::vector<double> > sphereGridNew = std::vector< std::vector<double> >( gridLA, std::vector<double>(gridLO) );
	for ( int i=halfSize; i<gridLA-halfSize; ++i )
	{
		for ( int j=halfSize; j<gridLO-halfSize; ++j )
		{
			double neighborTotal = 0.0;
			for ( int m=0; m<winSize; ++m )
			{
				for ( int n=0; n<winSize; ++n )
				{
					neighborTotal += _sphere_grid[i-halfSize+m][j-halfSize+n];
				}
			}

			sphereGridNew[i][j] = _sphere_grid[i][j] + neighborTotal / neighNum;
		}
	}
	_sphere_grid = sphereGridNew;	


	
}

/**
 * @description: *
 * @param {vector<std::vector<double> >} &sphere_grid 极坐标球
 * @param {vector<std::vector<Eigen::Vector3d> >} &vp_hypo 灭点假设
 * @param {vector<Eigen::Vector3d>} &vps 最佳的灭点
 * @return {*}
 * @author: fish
 */
void vanishing_point_detection::get_best_vps_hyp( std::vector<std::vector<double> > &sphere_grid, std::vector<std::vector<Eigen::Vector3d> >  &vp_hypo, std::vector<Eigen::Vector3d> &vps  ){
	int num = vp_hypo.size();
	double oneDegree = 1.0 / 180.0 * CV_PI;

	// get the corresponding line length of every hypotheses
	std::vector<double> lineLength( num, 0.0 );
	for ( int i = 0; i < num; ++ i )
	{
		std::vector<cv::Point2d> vpLALO( 3 ); 
		for ( int j = 0; j < 3; ++ j )
		{
			if (vp_hypo[i][j](2) == 0.0)
			{
				continue;
			}

			if ( vp_hypo[i][j](2) > 1.0 || vp_hypo[i][j](2) < -1.0 )
			{
				std::cout<<"1.00000"<<std::endl;
			}
			//转换为极坐标，找到对应网格
            double latitude = acos( vp_hypo[i][j](2) );
            double longitude = atan2( vp_hypo[i][j](0), vp_hypo[i][j](1) ) + CV_PI;


			int gridLA = int( latitude / oneDegree );
			if ( gridLA == 90 ) 
			{
				gridLA = 89;
			}
			
			int gridLO = int( longitude / oneDegree );
			if ( gridLO == 360 ) 
			{
				gridLO = 359;
			}
			//计算对应的lineLength，也就是响应数值
			lineLength[i] += sphere_grid[gridLA][gridLO];
		}
	}

	// get the best hypotheses 找到响应最大的一组假设
	int bestIdx = 0;
	double maxLength = 0.0;
	for ( int i = 0; i < num; ++ i )
	{
		if ( lineLength[i] > maxLength )
		{
			maxLength = lineLength[i];
			bestIdx = i;
		}
	}

	vps = vp_hypo[bestIdx];
}
void vanishing_point_detection::lines2Vps(std::vector<Line> &_cur_keylines, std::vector<Eigen::Vector3d> &_vps, std::vector<std::vector<int> > &_clusters,std::vector<int> &_vp_idx)
{
    _clusters.clear();
    _clusters.resize( 3 );

    int vps_size = 3;

    //get the corresponding vanish points on the image plane
    std::vector<cv::Point2d> vp2D( vps_size );
    for ( int i = 0; i < vps_size; ++ i )
    {
        vp2D[i].x =  _vps[i].x() * param.fx /
                     _vps[i].z() + param.cx;
        vp2D[i].y =  _vps[i].y() * param.fy /
                     _vps[i].z() + param.cy;
    }
	
	static std::vector<cv::Point2d>  vps_init = vp2D;

    for ( int i = 0; i < _cur_keylines.size(); ++ i )
    {
        double x1 = _cur_keylines[i].line_endpoint[0];
        double y1 = _cur_keylines[i].line_endpoint[1];

        double x2 = _cur_keylines[i].line_endpoint[2];
        double y2 = _cur_keylines[i].line_endpoint[3];
		//计算线段的中点
        double xm = ( x1 + x2 ) / 2.0;
        double ym = ( y1 + y2 ) / 2.0;



        double v1x = x1 - x2;
        double v1y = y1 - y2;
        double N1 = sqrt( v1x * v1x + v1y * v1y );
        v1x /= N1;   v1y /= N1;

        double minAngle = 1000.0;
        int bestIdx = 0;
		// 类
        for ( int j = 0; j < vps_size; ++ j )
        {
			//从线段中点引出一条到消影点的线段
            double v2x = vp2D[j].x - xm;
            double v2y = vp2D[j].y - ym;
            double N2 = sqrt( v2x * v2x + v2y * v2y );
            v2x /= N2;  v2y /= N2;

			// |a||b|cos<a,b>,获取线段与该消影点的角度偏差
            double crossValue = v1x * v2x + v1y * v2y;
            if ( crossValue > 1.0 )
            {
                crossValue = 1.0;
            }
            if ( crossValue < -1.0 )
            {
                crossValue = -1.0;
            }
            double angle = std::acos( crossValue );
            angle = std::min( CV_PI - angle, angle );

            if ( angle < minAngle )
            {

                minAngle = angle;
                bestIdx = j;
            }
        }

        //
        if ( minAngle < th_angle )
        {
            _clusters[bestIdx].push_back( i );
            _vp_idx.push_back(bestIdx);
        }
        else
            _vp_idx.push_back(3);
    }
}

void vanishing_point_detection::draw_clusters( cv::Mat &_img, std::vector<Line> &_lines, std::vector<std::vector<int> > &_clusters,std::vector<int> &_vp_idx,std::vector<Eigen::Vector3d> &_vps){
    cv::Mat vp_img;
    cv::Mat line_img;
    int cols = vp_img.cols;
    int rows = vp_img.rows;
	cv::cvtColor(_img.clone(), vp_img, cv::COLOR_GRAY2BGR);
    cv::cvtColor(_img.clone(), line_img, cv::COLOR_GRAY2BGR);

    //draw lines
    std::vector<cv::Scalar> lineColors( 3 );
	// brg
    lineColors[0] = cv::Scalar( 0, 0, 255 );//x  red
    lineColors[1] = cv::Scalar( 0, 255, 0 );//y green
    lineColors[2] = cv::Scalar( 255, 0, 0 );//z blue 

    std::vector<cv::Point2d> vp2D( _vps.size() );
    for ( int i = 0; i < _vps.size(); ++ i )
    {
        vp2D[i].x =  _vps[i].x() * param.fx /
                     _vps[i].z() + param.cx;
        vp2D[i].y =  _vps[i].y() * param.fy /
                     _vps[i].z() + param.cy;
    }
	cv::Point2d vp_init0(vp2D[0].x ,vp2D[0].y);
	cv::Point2d vp_init1(vp2D[1].x ,vp2D[1].y);
	cv::Point2d vp_init2(vp2D[2].x ,vp2D[2].y);

	for(int i=0; i<_vps.size(); ++i){
		// if(vp2D[i].x<fabs(vp_img.rows)&&vp2D[i].y<fabs(vp_img.cols))
		cv::circle(vp_img,cv::Point2f(vp2D[i].x,vp2D[i].y),10,lineColors[i],-1);
	}


    for ( int i=0; i<_lines.size(); ++i )
    {
        int idx = i;
        cv::Point2f pt_s = cv::Point2f(_lines[i].line_endpoint[0],_lines[i].line_endpoint[1]) ;
        cv::Point2f pt_e = cv::Point2f(_lines[i].line_endpoint[2],_lines[i].line_endpoint[3]) ;
        cv::Point pt_m = ( pt_s + pt_e ) * 0.5;

        cv::line( vp_img, pt_s, pt_e, cv::Scalar(0,0,0), 2, CV_AA );
        cv::line( line_img, pt_s, pt_e, cv::Scalar(0,255,255), 2, CV_AA );
    }

    for ( int i = 0; i < _clusters.size(); ++i )
    {
        for ( int j = 0; j < _clusters[i].size(); ++j )
        {
			// i 表示类
			// j 表示线索引
            int idx = _clusters[i][j];

        	cv::Point2d pt_s = cv::Point2d(_lines[idx].line_endpoint[0],_lines[idx].line_endpoint[1]) ;
        	cv::Point2d pt_e = cv::Point2d(_lines[idx].line_endpoint[2],_lines[idx].line_endpoint[3]) ;
            cv::Point2d pt_m = ( pt_s + pt_e ) * 0.5;
	
            cv::line( vp_img, pt_s, pt_e, lineColors[i], 2, CV_AA );

        }
		
    }
	img_vp_pub = vp_img.clone();
    // cv::imshow("img", _img);
    // cv::imshow("line img", line_img);
    // cv::imshow("vp img", vp_img);
    // cv::waitKey(1);
}