/*
 * @Description: 
 * @Version: 
 * @Author: 
 * @Date: 2022-11-30 22:35:04
 * @LastEditors: fish 973841082@qq.com
 * @LastEditTime: 2022-12-27 15:25:39
 */
#pragma once

#include <ceres/ceres.h>
#include <Eigen/Dense>
#include "../utility/line/line_geometry.h"
#include "line_parameterization.h"

#include "../utility/utility.h"
// struct LineProjectionFactor
// {
//     LineProjectionFactor(Matrix3d _ric, Vector3d _tic,Vector4d _obs)
//         : ric(_ric), tic(_tic),obs(_obs){
//             sp<<obs(0,0),obs(1,0),1.0;
//             ep<<obs(2,0),obs(3,0),1.0;
//         }

//     template <typename T>
//     bool operator()(const T* const pose, //7 rotation translation
//                     const T* const line, //4 orthonormal direction
//                     T* residuals) const
//     {
//         const Eigen::Matrix<T, 3, 1> t_wb(pose[0], pose[1], pose[2]);
//         const Eigen::Quaternion<T> q_wb(pose[6], pose[3], pose[4], pose[5]);
//         const Eigen::AngleAxis<T> roll(line[0], Matrix<T,3,1>::UnitX());
//         const Eigen::AngleAxis<T> pitch(line[1], Matrix<T,3,1>::UnitY());
//         const Eigen::AngleAxis<T> yaw(line[2], Matrix<T,3,1>::UnitZ());
//         const T pi = line[3];

//         Eigen::Matrix<T, 3, 3> R_wc = q_wb * ric.template cast<T>();
//         Eigen::Matrix<T, 3, 1> t_wc = q_wb * tic.template cast<T>() + t_wb;
//         Eigen::Matrix<T, 3, 3, RowMajor> Rotation_psi;
//         Rotation_psi = roll * pitch * yaw;

//         Matrix<T, 3, 1> n_w = cos(pi) * Rotation_psi.template block<3,1>(0,0);
//         Matrix<T, 3, 1> d_w = sin(pi) * Rotation_psi.template block<3,1>(0,1);
//         Matrix<T, 6, 1> l_w;
//         l_w.template block<3,1>(0,0) = n_w;
//         l_w.template block<3,1>(3,0) = d_w;

//         Matrix<T, 6, 6> T_cw;

//         Matrix<T, 3, 1> t_cw = -R_wc.transpose() * t_wc;
//         Matrix<T, 3, 3> t_cw_ss;
//         t_cw_ss << T(0.0), -t_cw(2), t_cw(1),
//                    t_cw(2), T(0.0), -t_cw(0),
//                    -t_cw(1), t_cw(0), T(0.0);

//         T_cw.setZero();
//         T_cw.template block<3,3>(0,0) = R_wc.transpose();
//         T_cw.template block<3,3>(0,3) = t_cw_ss * R_wc.transpose();
//         T_cw.template block<3,3>(3,3) = R_wc.transpose();

//         Matrix<T, 6, 1> l_c = T_cw * l_w;
//         Matrix<T, 3, 1> n_c = l_c.template block<3,1>(0,0);
//         Matrix<T, 3, 1> d_c = l_c.template block<3,1>(3,0);

//         residuals[0] = T(300.0) * sp.template cast<T>().dot(n_c)/sqrt(pow(n_c[0],2) + pow(n_c[1],2));
//         residuals[1] = T(300.0) * ep.template cast<T>().dot(n_c)/sqrt(pow(n_c[0],2) + pow(n_c[1],2));//        cout << residuals[0] << ", " << residuals[1] << endl;

//         return true;
//     }

// private:
//     Matrix3d ric;
//     Vector3d tic;
//     Vector4d obs;
//     Vector3d sp;
//     Vector3d ep;
// };
/*
  parameters[0]:  Twi
  parameters[1]:  Tbc
  parameters[2]:  line_orth
*/

// struct VPProjectionFactor
// {
//     VPProjectionFactor(Matrix3d _ric, Vector3d _tic, Vector3d _vp):vp(_vp),ric(_ric),tic(_tic){
        
//     }

//     template <typename T>
//     bool operator()(const T* const pose, //7 rotation translation
//                     const T* const line, //4 orthonormal direction
//                     T* residuals) const
//     {
//         const Eigen::Matrix<T, 3, 1> t_wb(pose[0], pose[1], pose[2]);
//         const Eigen::Quaternion<T> q_wb(pose[6], pose[3], pose[4], pose[5]);
//         const Eigen::AngleAxis<T> roll(line[0], Matrix<T,3,1>::UnitX());
//         const Eigen::AngleAxis<T> pitch(line[1], Matrix<T,3,1>::UnitY());
//         const Eigen::AngleAxis<T> yaw(line[2], Matrix<T,3,1>::UnitZ());
//         const T pi = line[3];

//         Eigen::Matrix<T, 3, 3> R_wc = q_wb * ric.template cast<T>();
//         Eigen::Matrix<T, 3, 1> t_wc = q_wb * tic.template cast<T>() + t_wb;
//         Eigen::Matrix<T, 3, 3, RowMajor> Rotation_psi;
//         Rotation_psi = roll * pitch * yaw;

//         Matrix<T, 3, 1> n_w = cos(pi) * Rotation_psi.template block<3,1>(0,0);
//         Matrix<T, 3, 1> d_w = sin(pi) * Rotation_psi.template block<3,1>(0,1);
//         Matrix<T, 6, 1> l_w;
//         l_w.template block<3,1>(0,0) = n_w;
//         l_w.template block<3,1>(3,0) = d_w;

//         Matrix<T, 6, 6> T_cw;

//         Matrix<T, 3, 1> t_cw = -R_wc.transpose() * t_wc;
//         Matrix<T, 3, 3> t_cw_ss;
//         t_cw_ss << T(0.0), -t_cw(2), t_cw(1),
//                    t_cw(2), T(0.0), -t_cw(0),
//                    -t_cw(1), t_cw(0), T(0.0);

//         T_cw.setZero();
//         T_cw.template block<3,3>(0,0) = R_wc.transpose();
//         T_cw.template block<3,3>(0,3) = t_cw_ss * R_wc.transpose();
//         T_cw.template block<3,3>(3,3) = R_wc.transpose();

//         Matrix<T, 6, 1> l_c = T_cw * l_w;
//         Matrix<T, 3, 1> n_c = l_c.template block<3,1>(0,0);
//         Matrix<T, 3, 1> d_c = l_c.template block<3,1>(3,0);

//         Matrix<T, 2, 1> d_c_2d(d_c(0)/d_c(2), d_c(1)/d_c(2));
//         Matrix<T, 2, 1> vp_2d(vp(0), vp(1));

//         residuals[0] = T(10.0) * (d_c_2d(0) - vp_2d(0));
//         residuals[1] = T(10.0)  * (d_c_2d(1) - vp_2d(1));

//     }
//     static ceres::CostFunction* Create(Matrix3d _ric, Vector3d _tic,Eigen::Vector3d obs_vps) 
//     {
//         return new ceres::AutoDiffCostFunction<VPProjectionFactor,
//                                            /* residual numbers */ 2,
//                                            /* first optimize numbers */ 7,
//                                             /* second optimize numbers */ 4>(
//         new VPProjectionFactor(_ric,_tic,obs_vps));
//     }
//     template <typename T>
//     Eigen::Matrix<T,6,1> plk_from_pose( Eigen::Matrix<T,6,1> plk_c, Eigen::Matrix<T,3,3> Rcw, Eigen::Matrix<T,3,1> tcw )const {

//         Eigen::Matrix<T,3,3> Rwc = Rcw.transpose();
//         Eigen::Matrix<T,3,1> twc = -Rwc*tcw;
//         return plk_to_pose( plk_c, Rwc, twc);
//     }
//     template <typename T>
//     Eigen::Matrix<T,6,1>  plk_to_pose( Eigen::Matrix<T,6,1>  plk_w, Eigen::Matrix<T,3,3>  Rcw, Eigen::Matrix<T,3,1>  tcw ) const{
//         Eigen::Matrix<T,3,1>  nw = plk_w.head(3);
//         Eigen::Matrix<T,3,1>  vw = plk_w.tail(3);

//         Eigen::Matrix<T,3,1>  nc = Rcw * nw + skew_symmetric(tcw) * Rcw * vw;
//         Eigen::Matrix<T,3,1>  vc = Rcw * vw;

//         Eigen::Matrix<T,6,1>  plk_c;
//         plk_c.head(3) = nc;
//         plk_c.tail(3) = vc;
//         return plk_c;
//     }
//     template <typename T>
//     Eigen::Matrix<T,6,1>  orth_to_plk(Eigen::Matrix<T,4,1>  orth) const
//     {
//         Eigen::Matrix<T,6,1>  plk;

//         Eigen::Matrix<T,3,1>  theta = orth.head(3);
//         T phi = orth[3];

//         T s1 = (T)sin(theta[0]);
//         T c1 = (T)cos(theta[0]);
//         T s2 = (T)sin(theta[1]);
//         T c2 = (T)cos(theta[1]);
//         T s3 = (T)sin(theta[2]);
//         T c3 = (T)cos(theta[2]);

//         Eigen::Matrix<T,3,3> R;
//         R <<
//         c2 * c3,   s1 * s2 * c3 - c1 * s3,   c1 * s2 * c3 + s1 * s3,
//                 c2 * s3,   s1 * s2 * s3 + c1 * c3,   c1 * s2 * s3 - s1 * c3,
//                 -s2,                  s1 * c2,                  c1 * c2;

//         T w1 = (T)cos(phi);
//         T w2 = (T)sin(phi);

//         Eigen::Matrix<T,3,1> u1 = R.col(0);
//         Eigen::Matrix<T,3,1> u2 = R.col(1);

//         Eigen::Matrix<T,3,1> n = w1 * u1;
//         Eigen::Matrix<T,3,1> v = w2 * u2;

//         plk.head(3) = n;
//         plk.tail(3) = v;
//         return plk;
//     }
// private:
//     Matrix3d ric;
//     Vector3d tic;
//     Vector3d vp;
// };
// class LineProjectionFactorAutoDiff
// {   
//     public:
//     LineProjectionFactorAutoDiff(const Eigen::Vector4d &_pts_i):obs_i(_pts_i){}

//     template <typename T>
//     bool operator()(const T *Twi, const T *Tic,const T *_line_w, T *residuals)const{
//         // // 从parameter获取变量
//         // Eigen::Matrix<T, 3, 1> Pi{T(Twi[0]), T(Twi[1]), T(Twi[2])};
//         // Eigen::Quaternion<T> Qi{T(Twi[6]), T(Twi[3]), T(Twi[4]), T(Twi[5])};

//         // Eigen::Matrix<T, 3, 1> tic{T(Tic[0]), T(Tic[1]), T(Tic[2])};
//         // Eigen::Quaternion<T> qic{T(Tic[6]), T(Tic[3]), T(Tic[4]), T(Tic[5])};

//         // Eigen::Matrix<T, 4, 1> line_orth{T(_line_w[0]), T(_line_w[1]), T(_line_w[2]),T(_line_w[3])};
//         // // 获取线的普吕克坐标系
//         // Eigen::Matrix<T,6,1> line_w = orth_to_plk1(line_orth);

//         // // body坐标系
//         // Eigen::Matrix<T, 3, 3> Rwb(Qi);
//         // Eigen::Matrix<T, 3, 1> twb(Pi);
//         // Eigen::Matrix<T,6,1> line_b = plk_from_pose1(line_w, Rwb, twb);
//         // // // 相机坐标系
//         // Eigen::Matrix<T, 3, 3> Rbc(qic);
//         // Eigen::Matrix<T, 3, 1> tbc(tic);
//         // Eigen::Matrix<T,6,1> line_c = plk_from_pose1(line_b, Rbc, tbc);
//         // // 直线的投影矩阵K为单位阵
//         // //  分母计算
//         // Eigen::Matrix<T, 3, 1> nc = line_c.head(3);
//         // T l_norm = T(nc(0) * nc(0) + nc(1) * nc(1));
//         // T l_sqrtnorm = T(sqrt( l_norm ));

//         // T e1 = T(obs_i(0) * nc(0)) + T(obs_i(1) * nc(1) )+ T(nc(2));
//         // T e2 = T(obs_i(2) * nc(0)) + T(obs_i(3) * nc(1) )+ T(nc(2));
//         // Eigen::Map<Eigen::Matrix<T, 2, 1> > residual(residuals);

        
//         // residual(0) = e1/l_sqrtnorm;
//         // residual(1) = e2/l_sqrtnorm;
//         // residual = sqrt_info * residual;
//         return true;
//     }
//     static ceres::CostFunction* Create(const Eigen::Vector4d& obs_lines) 
//     {
//     return new ceres::AutoDiffCostFunction<LineProjectionFactorAutoDiff,
//                                            /* residual numbers */ 2,
//                                            /* first optimize numbers */ 7,
//                                            /* second optimize numbers */ 7,
//                                             /* second optimize numbers */ 4>(
//         new LineProjectionFactorAutoDiff(obs_lines));
//     }
//     EIGEN_MAKE_ALIGNED_OPERATOR_NEW
//     Eigen::Vector4d obs_i;
//     static Eigen::Matrix2d sqrt_info;

// };

class vplineProjectionFactor : public ceres::SizedCostFunction<2, 7, 7, 4>
{
  public:
    vplineProjectionFactor(const Eigen::Vector3d &_pts_i);
    virtual bool Evaluate(double const *const *parameters, double *residuals, double **jacobians) const;
    void check(double **parameters);

    Eigen::Vector3d obs_i;
    Eigen::Matrix<double, 2, 3> tangent_base;
    static Eigen::Matrix2d sqrt_info;
    static double sum_t;
};


class lineProjectionFactor : public ceres::SizedCostFunction<2, 7, 7, 4>
{
  public:
    lineProjectionFactor(const Eigen::Vector4d &_pts_i);
    virtual bool Evaluate(double const *const *parameters, double *residuals, double **jacobians) const;
    void check(double **parameters);

    Eigen::Vector4d obs_i;
    Eigen::Matrix<double, 2, 3> tangent_base;
    static Eigen::Matrix2d sqrt_info;
    static double sum_t;
};

///////////////////////////////line in camera frame///////////////////////////////////////////
class lineProjectionFactor_incamera : public ceres::SizedCostFunction<2, 7, 7, 7, 4>
{
public:
    lineProjectionFactor_incamera(const Eigen::Vector4d &_pts_i);
    virtual bool Evaluate(double const *const *parameters, double *residuals, double **jacobians) const;
    void check(double **parameters);

    Eigen::Vector4d obs_i;
    Eigen::Matrix<double, 2, 3> tangent_base;
    static Eigen::Matrix2d sqrt_info;
    static double sum_t;
};
class lineProjectionFactor_instartframe : public ceres::SizedCostFunction<2, 4>
{
public:
    lineProjectionFactor_instartframe(const Eigen::Vector4d &_pts_i);
    virtual bool Evaluate(double const *const *parameters, double *residuals, double **jacobians) const;
    void check(double **parameters);

    Eigen::Vector4d obs_i;
    Eigen::Matrix<double, 2, 3> tangent_base;
    static Eigen::Matrix2d sqrt_info;
    static double sum_t;
};