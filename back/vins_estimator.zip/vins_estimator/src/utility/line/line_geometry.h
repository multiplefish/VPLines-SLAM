//
// Created by hyj on 17-12-8.
//

#ifndef VINS_ESTIMATOR_LINE_GEOMETRY_H
#define VINS_ESTIMATOR_LINE_GEOMETRY_H
#include <eigen3/Eigen/Dense>
using namespace Eigen;
typedef Matrix<double,6,1> Vector6d;
typedef Matrix<double,8,1> Vector8d;
typedef Matrix<double,6,6> Matrix6d;

/**
 * @description: *普吕克转正交表示
 * @param {Vector6d} line
 * @return {*}
 * @author: fish
 */
Vector4d line_to_orth(Vector6d line);

/**
 * @description: *正交转普吕克
 * @param {Vector4d} orth
 * @return {*}
 * @author: fish
 */
Vector6d orth_to_line(Vector4d orth);
/**
 * @description: *普吕克转正交表示
 * @param {Vector6d} line
 * @return {*}
 * @author: fish
 */
Vector4d plk_to_orth(Vector6d plk);
/**
 * @description: *正交转普吕克
 * @param {Vector4d} orth
 * @return {*}
 * @author: fish
 */
Vector6d orth_to_plk(Vector4d orth);

/**
 * @description: 普吕克转近邻点表示
 * @param {Vector6d} plk
 * @return {*}
 * @author: fish
 */
Vector4d plk_to_point(Vector6d plk);

/**
 * @description: 端点表示法
 * @param {Vector3d} pi1
 * @param {Vector3d} pi2
 * @return {*}
 * @author: fish
 */
Vector6d pp_plk( Vector3d pi1, Vector3d pi2);

/**
 * @description: 3点成面
 * @param {Vector3d} x1
 * @param {Vector3d} x2
 * @param {Vector3d} x3
 * @return {*}
 * @author: fish
 */
Vector4d pi_from_ppp(Vector3d x1, Vector3d x2, Vector3d x3);

/**
 * @description: 两面相交表示法
 * @param {Vector4d} pi1
 * @param {Vector4d} pi2
 * @return {*}
 * @author: fish
 */
Vector6d pipi_plk( Vector4d pi1, Vector4d pi2);

/**
 * @description: 普吕克到光心距离
 * @param {Vector3d} n
 * @param {Vector3d} v
 * @return {*}
 * @author: fish
 */
Vector3d plucker_origin(Vector3d n, Vector3d v);

/**
 * @description: 反对陈矩阵
 * @param {Vector3d} v
 * @return {*}
 * @author: fish
 */
Matrix3d skew_symmetric( Vector3d v );

/**
 * @description: *点的坐标变化
 * @param {Matrix3d} Rcw
 * @param {Vector3d} tcw
 * @param {Vector3d} pt_c
 * @return {*}
 * @author: fish
 */
Vector3d poit_from_pose( Eigen::Matrix3d Rcw, Eigen::Vector3d tcw, Vector3d pt_c );
Vector3d point_to_pose( Eigen::Matrix3d Rcw, Eigen::Vector3d tcw , Vector3d pt_w );

/**
 * @description: 普吕克坐标系之间的坐标变化
 * @param {Vector6d} line_w
 * @param {Matrix3d} Rcw
 * @param {Vector3d} tcw
 * @return {*}
 * @author: fish
 */
Vector6d line_to_pose(Vector6d line_w, Eigen::Matrix3d Rcw, Eigen::Vector3d tcw);
Vector6d line_from_pose(Vector6d line_c, Eigen::Matrix3d Rcw, Eigen::Vector3d tcw);
/**
 * @description: 普吕克坐标系之间的坐标变化
 * @param {Vector6d} line_w
 * @param {Matrix3d} Rcw
 * @param {Vector3d} tcw
 * @return {*}
 * @author: fish
 */
Vector6d plk_to_pose( Vector6d plk_w, Eigen::Matrix3d Rcw, Eigen::Vector3d tcw );
Vector6d plk_from_pose( Vector6d plk_c, Eigen::Matrix3d Rcw, Eigen::Vector3d tcw );

#endif //VINS_ESTIMATOR_LINE_GEOMETRY_H
